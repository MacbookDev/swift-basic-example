import SwiftUI

func greet(person: String, from hometown: String) -> String {
    return "Hello \(person)!  Glad you could visit from \(hometown)."
}
print(greet(person: "Bill", from: "Cupertino"))

class Counter {
    var count = 0
    var test = ""
    func increment() {
        self.count += 1
        self.test="asd"
    }
    func increment(by amount: Int) {
        self.count += amount
        self.test="asd"
    }
    func reset() {
        self.count = 0
    }
}
 
let counter = Counter()
counter.increment(by: 1)
print(counter.count)
print(counter.test)

struct CounterStruct {
    var count = 0
    var test = ""
    mutating func increment() {
        self.count += 1
        self.test="asd"
    }
    mutating func increment(by amount: Int) {
        self.count += amount
        self.test="asd"
    }
    mutating func reset() {
        self.count = 0
    }
}

class IsChanged {
    func handleChange() {
        if Counter().count > 0 {
            print("yes")
        }
    }
}

var counter_struct = CounterStruct()
counter_struct.increment(by: 1)

IsChanged().handleChange()

